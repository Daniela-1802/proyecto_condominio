import 'package:dio/dio.dart';
import '../env.dart';
import 'storage/secure_storage.dart';

class ApiClient {
  final Dio dio = Dio(BaseOptions(baseUrl: Env.baseUrl));
  final AppSecureStorage storage = AppSecureStorage();

  ApiClient() {
    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (o, h) async {
        final t = await storage.readAccess();
        if (t != null && t.isNotEmpty) {
          o.headers['Authorization'] = 'Bearer $t';
        }
        h.next(o);
      },
      onError: (e, h) async {
        // Si el access expira, intenta refresh automáticamente
        if (e.response?.statusCode == 401 && await _refresh()) {
          final req = e.requestOptions;
          final t = await storage.readAccess();
          req.headers['Authorization'] = 'Bearer $t';
          final retry = await dio.fetch(req);
          return h.resolve(retry);
        }
        h.next(e);
      },
    ));
  }

  Future<bool> _refresh() async {
    try {
      final r = await storage.readRefresh();
      if (r == null) return false;
      final res = await dio.post(Env.refreshPath, data: {'refresh': r});
      final newAccess = res.data['access'] as String?;
      if (newAccess == null) return false;
      await storage.saveTokens(access: newAccess, refresh: r);
      return true;
    } catch (_) {
      await storage.clear();
      return false;
    }
  }
}
