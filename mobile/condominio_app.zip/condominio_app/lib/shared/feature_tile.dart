import 'package:flutter/material.dart';

class FeatureTile extends StatelessWidget {
  final String cu;
  final String title;
  final String? subtitle;
  final IconData icon;
  final VoidCallback? onTap;

  const FeatureTile({
    super.key,
    required this.cu,
    required this.title,
    this.subtitle,
    required this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        width: 180,
        height: 120,
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color ?? Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: cs.onSurface.withOpacity(.06)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: cs.secondary.withOpacity(.15), borderRadius: BorderRadius.circular(999)),
                child: Text(cu, style: Theme.of(context).textTheme.labelMedium),
              ),
              const Spacer(),
              Icon(icon, color: cs.primary),
            ]),
            const Spacer(),
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            if (subtitle != null)
              Text(subtitle!, style: Theme.of(context).textTheme.bodySmall!.copyWith(color: cs.onSurfaceVariant)),
          ]),
        ),
      ),
    );
  }
}
