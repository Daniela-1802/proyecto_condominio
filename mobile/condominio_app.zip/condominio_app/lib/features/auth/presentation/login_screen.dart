import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import '../../core/shell.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.apartment_rounded, size: 64, color: cs.secondary),
                  const Gap(10),
                  Text(
                    'SmartCondominium',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleLarge!.copyWith(fontWeight: FontWeight.w800),
                  ),
                  const Gap(18),
                  const TextField(decoration: InputDecoration(labelText: 'Usuario', prefixIcon: Icon(Icons.person_outline))),
                  const Gap(12),
                  const TextField(obscureText: true, decoration: InputDecoration(labelText: 'Contraseña', prefixIcon: Icon(Icons.lock_outline))),
                  const Gap(18),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const AppShell()));
                    },
                    child: const Text('Iniciar sesión (mock)'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
