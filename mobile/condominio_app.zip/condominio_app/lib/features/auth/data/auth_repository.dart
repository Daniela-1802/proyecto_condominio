import 'package:dio/dio.dart';
import '../../../core/api_client.dart';
import '../../../core/storage/secure_storage.dart';
import '../../../env.dart';

class AuthRepository {
  final ApiClient api;
  final AppSecureStorage storage;

  AuthRepository({ApiClient? api, AppSecureStorage? storage})
      : api = api ?? ApiClient(),
        storage = storage ?? AppSecureStorage();

  Future<void> login(String username, String password) async {
    try {
      final res = await api.dio.post(Env.tokenPath, data: {
        'username': username,
        'password': password,
      });
      final access  = res.data['access']  as String?;
      final refresh = res.data['refresh'] as String?;
      if (access == null || refresh == null) {
        throw Exception('Respuesta inválida del servidor');
      }
      await storage.saveTokens(access: access, refresh: refresh);
    } on DioException catch (e) {
      final msg = e.response?.data?.toString() ?? 'Error de red';
      throw Exception('No se pudo iniciar sesión: $msg');
    }
  }

  /// CU02: cerrar sesión de forma correcta
  Future<void> logout() async {
    try {
      final refresh = await storage.readRefresh();
      if (refresh != null && refresh.isNotEmpty) {
        // Blacklist del refresh en el backend
        await api.dio.post(Env.logoutPath, data: {'refresh': refresh});
      }
    } catch (_) {
      // No interrumpas el flujo si falla el POST; igual limpiarás el storage
    } finally {
      await storage.clear(); // borrar access y refresh
    }
  }
}
