import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perfil')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            const CircleAvatar(radius: 28, child: Icon(Icons.person)),
            const Gap(12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Nombre del Usuario', style: Theme.of(context).textTheme.titleMedium),
              const Text('Apartamento B-203'),
            ]),
          ]),
          const Gap(20),
          ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Ajustes'), onTap: () {}),
          ListTile(leading: const Icon(Icons.privacy_tip_outlined), title: const Text('Privacidad'), onTap: () {}),
          const Gap(20),
          ElevatedButton.icon(onPressed: () {}, icon: const Icon(Icons.logout), label: const Text('Cerrar sesión (CU02)')),
        ],
      ),
    );
  }
}
