class Env {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    // Si vas a probar en Web/Chrome: http://127.0.0.1:8000
    // Si vas a probar en emulador Android: http://10.0.2.2:8000
    // Si vas a probar en teléfono: http://<IP_PC>:8000
    defaultValue: 'http://127.0.0.1:8000',
  );

  // Nuevos endpoints según tu urls.py
  static const tokenPath   = '/api/auth/login/';    // TokenObtainPairView
  static const refreshPath = '/api/auth/refresh/';  // TokenRefreshView
  static const logoutPath  = '/api/auth/logout/';   // TokenBlacklistView
}
